$(function () {
  $('select').formSelect();
  $('.datepicker').datepicker();
  $('.modal').modal();
  $('.scrollspy').scrollSpy();
  $('.sidenav').sidenav();
  $('.tabs').tabs();
  $('.dropdown-trigger').dropdown();
  $('.dropdown-hover').dropdown({
    hover: true
  });

  $('.btn_banner_01').click(function(){
    $('.banner-top-2').toggleClass('on');
  })
});
