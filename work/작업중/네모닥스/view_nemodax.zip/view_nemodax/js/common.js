$(function () {
  $('select').formSelect();
  $('.datepicker').datepicker();
  $('.modal').modal();
  $('.scrollspy').scrollSpy();
  $('.sidenav').sidenav();
  $('.tabs').tabs();
  $('.dropdown-trigger').dropdown();
});